### jsoncons::half_arg

```cpp
#include <jsoncons/tag_type.hpp>

constexpr half_arg_t half_arg{};
```

A constant of type [half_arg_t](half_arg_t.md) used as first argument to disambiguate constructor overloads for half precision floating point numbers.

