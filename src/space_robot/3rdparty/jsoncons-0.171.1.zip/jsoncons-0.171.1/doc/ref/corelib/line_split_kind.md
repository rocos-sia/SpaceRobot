### jsoncons::line_split_kind

```cpp
#include <jsoncons/json_options.hpp>

enum class line_split_kind{same_line,new_line,multi_line};
```

