### keys

```
array[string] keys(object value)
```

Returns an array of keys in the object.

It is a type error if the provided argument is not an object.

### Examples


